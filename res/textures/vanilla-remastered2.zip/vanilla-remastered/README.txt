Vanilla Remastered
Version 2
By susbaconhairman
--------------------
Installation (Computer/mobile only):

1. Extract the archive
2. Copy the 'achievements.3dst', 'sdcard_icon.3dst', and 'spritesheet.3dst' files from the '/romfs/resourcepacks/vanilla/client/textures/gui/' folder in the extracted archive
3. Paste the files to '/luma/titles/XXXX/romfs/resourcepacks/vanilla/client/textures/gui/'
	Replace 'XXXX' in the directory path with one of the following:
	'00040000001B8700' for USA-region consoles
	'000400000017CA00' for European-region consoles
	'000400000017FD00' for Japanese-region consoles
4. Make sure Game Patching is enabled in the Luma Configuration Settings!
--------------------
Credits:

Ohana3DS for texture conversion
Pixlr and Piskel for image manipulation
Minecraft Privacy Prodigy world for the SD card icon
Minecraft Wiki for other images
Minecraft: New Nintendo 3DS Edition sprites for reference
7-Zip for archiving
paint.net for image manipulation too
Steve Jobs I guess
Windows for doing stuff
Minecraft 3DS Community for support
And you for downloading this, thanks!