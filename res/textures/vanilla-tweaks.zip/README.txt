Vanilla Tweaks
Version 1
By susbaconhairman
--------------------
Installation:

1. Extract the archive
2. Copy the 'achievements.3dst' and 'sdcard_icon.3dst' files from the '/romfs/resourcepacks/vanilla/textures/gui/' folder in the extracted archive
3. Paste the files to '/luma/titles/XXXX/romfs/resourcepacks/vanilla/textures/gui/'
	Replace 'XXXX' in the directory path with one of the following:
	'00040000001B8700' for USA-region consoles
	'000400000017CA00' for European-region consoles
	'000400000017FD00' for Japanese-region consoles
4. Make sure Game Patching is enabled in the Luma Configuration Settings
--------------------
Credits:

Ohana3DS for texture conversion
Pixlr and Piskel for image manipulation
Minecraft Privacy Prodigy world for the SD card icon
Minecraft: New Nintendo 3DS Edition sprites for reference
Minecraft 3DS Community for support