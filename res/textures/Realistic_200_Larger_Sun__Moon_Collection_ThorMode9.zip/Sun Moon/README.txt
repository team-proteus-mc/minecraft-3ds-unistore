Minecraft - New Nintendo 3DS Edition (v1.9.19)
Realistic/200% Larger Sun + Moon Texture

This texture pack collection increases the sun and moon size by 200% as well as
provides realistic textures and moon phase cycles for higher resolution worlds.
This will be applied to the sun and moon on all texture packs with the exception
of Vanilla. (Vanilla will be included in a future update).
_______________________________________________________________________________

Original Textures:
ThorMode9
_______________________________________________________________________________

Contents:
Realistic 200% Larger Sun + Blood Moon (Every Full Moon)
Blood moon behavior: Blood moon will spawn every eighth night, or every full moon.

Realistic 200% Larger Sun + Blood Moon (Every Night - Full Moon)
Blood moon behavior: Every night will be a full blood moon.

Realistic 200% Larger Sun + Blood Moon (Every Night - Phases)
Blood moon behavior: Every night will be a blood moon with default phases.

Realistic 200% Larger Sun + Moon

_______________________________________________________________________________

Instructions:
Place the appropriate contents provided based on your region into the "titles"
folder on your New Nintendo 3DS/2DS micro SD card as shown below:

SD:/luma/titles/00040000001B8700 (USA)
SD:/luma/titles/000400000017CA00 (Europe)
SD:/luma/titles/000400000017FD00 (Japan)

Insert the micro SD into your New Nintendo 3DS/2DS.

To enable game patching, power on the system on while holding 'Select' to access the
Luma3DS configuration menu. Highlight "Enable Game Patching" and press 'A' to enable.
Press 'Start' to save the configuration settings.

Open Minecraft - New Nintendo 3DS Edition to access the updated content.