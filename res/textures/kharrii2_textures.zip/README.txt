===============================================================================
Minecraft - New Nintendo 3DS Edition (v1.9.19)
Kharrii2 Dirt/Grass Block Face Pack 1.19.3

Resolution: 16x16

Port
By: skribbler#1095

Original Textures
By: MegaMinerDL

Sources:
https://www.planetminecraft.com/texture-pack/kharrii2-grass-dirt-block-pack-anyversion/
===============================================================================
Title IDs:

00040000001B8700 (USA)
000400000017CA00 (Europe)
000400000017FD00 (Japan)
-------------------------------------------------------------------------------
Instructions:

1. Remove the microSD card from your New Nintendo 3DS/2DS XL and stick it into
your computer via an adapter of choice that can read said storage card.

2. Open the "luma" folder, create a folder called "titles" inside, skip this
step if you already have a folder with this name present.

3. Stick the contents provided into the "titles" folder. The end result should
be the following:

USA
SD:/luma/titles/00040000001B8700

Europe
SD:/luma/titles/000400000017CA00

Japan
SD:/luma/titles/000400000017FD00

4. Safely eject the microSD card, remove the microSD card from your adapter,
then stick said storage card back into your New Nintendo 3DS/2DS XL. Press and
hold Select, power the system on while still holding Select to access the
Luma3DS configuration menu. In here you will want to make sure that "Enable Game
Patching" is set to enabled (indicated by an (x) to the left of the option). Press
Start to save the configuration settings.

5. Open the game and have fun!!!