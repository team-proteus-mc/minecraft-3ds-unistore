Minecraft - New Nintendo 3DS Edition (v1.9.19)
Norse Mythology Mash-up Panorama Texture Pack

Add the Norse Mythology Mash-Up Panorama to your base title screen with this panorama texture pack!
________________________________________________________________

Original textures by:
4J Studios

Ported by:
ThorMode9
________________________________________________________________

Contents:
Norse Mythology Mash-up Panorama (Base)
________________________________________________________________

Instructions:
Place the appropriate contents provided based on your region
into the 'titles' folder on your New Nintendo 3DS/2DS MicroSD
card as shown below:

SD:/luma/titles/00040000001B8700 (USA)
SD:/luma/titles/000400000017CA00 (Europe)
SD:/luma/titles/000400000017FD00 (Japan)

Insert the micro SD into your New Nintendo 3DS/2DS.

To enable game patching, power the system on while holding
'Select' to access the Luma3DS configuration menu. Highlight
'Enable Game Patching' and press 'A' to enable. Press 'Start'
to save the configuration settings.

Open Minecraft - New Nintendo 3DS Edition to access the
updated content.