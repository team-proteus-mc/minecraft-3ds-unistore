ABOUT:
LEGO Minecraft - Dragon Slayer (official skin)
Unofficially ported to Minecraft: New Nintendo 3DS Edition by susbaconhairman (skribbler#1095)
This is my first mod for the game!
Thanks to WaterMelon, Dark, and noviscera on the Minecraft 3DS Community Discord server (https://discord.gg/PcfekvmjSw) for helping me, and this video: https://www.youtube.com/watch?v=zpUeEvCYXRE

INSTRUCTIONS:
- You'll need a New Nintendo 3DS (XL)/2DS XL with Homebrew (find more about it here: https://3ds.hacks.guide)
- And you'll need the game of course

1. Put your 3DS's microSD card into your PC.

2. Open it on your PC.

3. Go to luma (create one folder with the name luma on the root of the card if you don't have one).

4. Go to titles (create one folder with the name titles if you don't have one).

5. Go to Minecraft: New Nintendo 3DS Edition's title ID. this one depends of the region you're in. (create one folder with the corresponding title ID if you don't have one)

Title IDs:

00040000001B8700 (USA)
000400000017CA00 (Europe)
000400000017FD00 (Japan)

6. Go to romfs (create one folder with the name romfs if you don't have one)

7. Go to resourcepacks (create one folder with the name resourcepacks if you don't have one)

8. Go to skins (create one folder with the name skins if you don't have one)

9. Go to skinpacks (create one folder with the name skinpacks if you don't have one)

10. And put the Base folder in there.

11. Safely eject the microSD card, remove the microSD card from your adapter,
then stick said storage card back into your New Nintendo 3DS (XL)/2DS XL. Press Select + Power, and you should be brought to the Luma3DS configuration menu. In here you will want to make sure that "Enable Game
Patching" is set to enabled (indicated by an (x) to the left of the option). Press
Start to save the configuration settings.

12. And now open your game and try your skins out (the skins name will be Steve, and in Steve's place in the skin selection).

If you're currently using any custom skin(s) with the use of the Base skinpack, just move it to another skinpack or completely delete it.

Thanks for downloading!