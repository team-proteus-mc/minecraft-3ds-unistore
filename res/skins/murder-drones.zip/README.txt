MADE BY skribbler#1095/susbaconhairman/skribbler/BigSkribbz
Port of these skins: https://sites.google.com/view/mccontent/murder-drones-skinpack

MURDER DRONES SKIN PACK FOR MINECRAFT: NEW NINTENDO 3DS EDITION

These replace most of the Town Folk skins.

HOW TO INSTALL:
Extract the ZIP file, then drag and drop the TownFolk folder from the ZIP into /luma/titles/xxxx/romfs/resourcepacks/skins/skinpacks/. Create any required directories if necessary.
Replace xxxx with the proper title ID. The USA title ID is 00040000001B8700, the European title ID is 000400000017CA00, and the Japanese title ID is 000400000017FD00.
Make sure to enable game patching in the Luma3DS settings for this to work! If this isn't enabled already, then make sure your system is powered off, hold start while pressing the power button. Scroll down until you see the "Enable game patching" option, and press the A button to enable it, then press the START button to save.