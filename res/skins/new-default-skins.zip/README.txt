New Minecraft Bedrock/Java Default Skins
By susbaconhairman
Port of official skins by Mojang

This pack includes 11 skins, and replaces some of the Halloween Costume skins.

Here is a list of them and what skin they replace in-game:

Steve (Java) - Zombie Costume
Alex (Java) - Iron-Golem Costume
Steve (Bedrock) - Creeper Costume
Zuri - Cow Costume
Alex (Bedrock) - Enderman Costume
Noor - Ghast Costume
Makena - Mooshroom Costume
Efe - Ocelot Costume
Kai - Pig Costume
Ari - Rainbow Sheep Costume
Sunny - Skeleton Costume