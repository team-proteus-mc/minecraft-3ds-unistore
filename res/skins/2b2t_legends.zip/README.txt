2B2T Legends, by susbaconhairman

How to install:
Drag and drop the CityFolk folder into /luma/titles/xxxx/romfs/resourcepacks/skins/skinpacks/
Enter the following number for xxxx:
00040000001B8700 - USA-
000400000017CA00 - European-
000400000017FD00 - Japanese-consoles