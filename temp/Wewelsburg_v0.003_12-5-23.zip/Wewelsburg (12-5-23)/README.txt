Minecraft - New Nintendo 3DS Edition (v1.9.19)
Wewelsburg v0.003 (2016 × 2016)

This map is an ongoing project loosely inspired by the architecture of German
Renaissance castle, Wewelsburg, located in the village of Wewelsburg, which is
a district of the town of Büren, Westphalia, in the Landkreis of Paderborn in
the northeast of North Rhine-Westphalia, Germany.
_______________________________________________________________________________

Updates:

Added more structures. 
Expansion of massive caves and cliffs.
Rain and lightning frequency decreased.
_______________________________________________________________________________

Build
By: ThorMode9